package com.gov.restapi.GovRestApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GovRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
