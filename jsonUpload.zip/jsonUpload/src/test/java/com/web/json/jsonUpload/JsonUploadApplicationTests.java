package com.web.json.jsonUpload;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsonUploadApplicationTests {

	@Test
	void contextLoads() {
	}

}
