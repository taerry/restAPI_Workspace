package com.web.json.jsonUpload;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JsonUploadApplication {

	public static void main(String[] args) {
		SpringApplication.run(JsonUploadApplication.class, args);
	}

}
