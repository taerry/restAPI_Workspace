package com.sping.MakeDev;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MakeDeveloperApplication {

	public static void main(String[] args) {
		SpringApplication.run(MakeDeveloperApplication.class, args);
	}

}
