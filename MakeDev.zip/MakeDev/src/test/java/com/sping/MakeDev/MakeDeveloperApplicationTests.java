package com.sping.MakeDev;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MakeDeveloperApplicationTests {

	@Test
	void contextLoads() {
	}

}
