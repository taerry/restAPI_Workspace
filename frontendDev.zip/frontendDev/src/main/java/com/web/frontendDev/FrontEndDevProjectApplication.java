package com.web.frontendDev;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FrontEndDevProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(FrontEndDevProjectApplication.class, args);
	}

}
