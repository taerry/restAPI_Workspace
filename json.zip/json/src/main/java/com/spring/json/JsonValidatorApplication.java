package com.spring.json;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JsonValidatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(JsonValidatorApplication.class, args);
	}

}
