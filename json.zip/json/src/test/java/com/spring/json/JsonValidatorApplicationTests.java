package com.spring.json;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsonValidatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
